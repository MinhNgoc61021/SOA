#include <bits/stdc++.h>
#define maxN 1000
using namespace std;

struct process{
	int pid, bt, art;
	int turnArroundTime;
	int waitingTime;
	int respondTime;
	int serviceTime;
	int finishTime;
	int remainingTime;
};

bool arrivalComparison(process a, process b) {
	return a.art < b.art;
}

bool burstComparison(process a, process b) {
	if (a.bt > b.bt)
		return true;
	if (a.bt == b.bt) {
		if (a.pid < b.pid)
			return true;
		else 
			return false;
	}
	return false;

}

void print(process proc[], int n) {
	int totalTurnAroundTime = 0, totalWaitingTime = 0;

	cout << "Process " << " Arrival " << " Burst time "
         << " Waiting " << " Turn-Around " << " Response time "
         << " Finish time \n";

    for (int i = 0; i < n; i++) {

    	proc[i].turnArroundTime = proc[i].waitingTime + proc[i].bt;
    	proc[i].finishTime = proc[i].turnArroundTime + proc[i].art;

    	cout << proc[i].pid << "\t\t\t"
    		 << proc[i].art << "\t\t\t"
    		 << proc[i].bt << "\t\t"
    		 << proc[i].waitingTime << "\t\t\t"
    		 << proc[i].turnArroundTime << "\t\t\t"
    		 << proc[i].respondTime << "\t\t\t"
    		 << proc[i].finishTime
    		 << endl;

    	totalTurnAroundTime += proc[i].turnArroundTime;
		totalWaitingTime += proc[i].waitingTime;
    }

    printf("\nThrough put: %.5f", float(n) / proc[n-1].finishTime);
    printf("\nAverage waiting time: %.5f", float(totalWaitingTime) / float(n));
    printf("\nAverage turn around time: %.5f", float(totalTurnAroundTime) / n);
}

void FCFS(process proc[], int n) {
	cout << "\t\t\t\t\tFirst Come First Served" << endl;
	sort(proc, proc + n, arrivalComparison);

	proc[0].respondTime = 0;
	for (int i = 1; i < n; i++) {
		proc[i].serviceTime = proc[i-1].serviceTime + proc[i-1].bt;
		proc[i].waitingTime = max(0, proc[i].serviceTime - proc[i].art);
		proc[i].respondTime = proc[i].waitingTime;
	}
	print(proc, n);
}

void SJF(process proc[], int n) {
	cout << "\n\n\t\t\t\t\tShortest Job First" << endl;
	sort(proc, proc + n, arrivalComparison);

	process myQ[maxN], out[maxN];
	int i = 0;
	int N = -1;
	int m = 0;
	int time = 0;
	while (1) {
		while (i < n) {
			if ( proc[i].art <= time ) 
				myQ[m++] = proc[i];
			else 
				break;
			i++;
		}	
		sort(myQ, myQ + m, burstComparison);
		out[++N] = myQ[--m];
		out[N].respondTime = out[N].waitingTime;
		out[N].waitingTime = time - out[N].art;
		time += out[N].bt;
		if ( m <= 0 && i >= n)
			break;
	}
	print(out, n);
}

void SRTF(process proc[], int n) {
	cout << "\n\n\t\t\t\t\tShortest Remaining Time First" << endl;
	sort(proc, proc + n, arrivalComparison);

	process myQ[maxN], out[maxN];
	int i = 0;
	int N = -1;
	int m = 0;
	int time = -1;
	while (1) {
		time++;
		while (i < n) {
			if ( proc[i].art <= time ) 
				myQ[m++] = proc[i];
			else 
				break;
			i++;
		}	
		sort(myQ, myQ + m, burstComparison);
		//cout << time << " " << myQ[m-1].pid << " " << endl;
		if (myQ[m-1].respondTime == -1)
			myQ[m-1].respondTime = time - myQ[m-1].art;
		for (int ii = 0; ii < m-1; ii++) {
			myQ[ii].waitingTime++;
		}
		myQ[m-1].remainingTime--;
		if (myQ[m-1].remainingTime == 0) {
			out[++N] = myQ[--m];
		}

		if ( m <= 0 && i >= n)
			break;

	}
	for (int i = 0; i < n; i++)
		proc[i].art = 0;
	print(out, n);
}

void QT(process proc[], int n, int quantum) {

	cout << "\n\n\t\t\t\t\t Time Quantum\n";
	int time = 0;

	while (1) {
		bool done = true;

		for (int i = 0; i < n; i++) 
			if (proc[i].remainingTime > 0) {
				done = false;
				if (proc[i].remainingTime > quantum) {
					proc[i].remainingTime -= quantum;
					time += quantum;
				} else {
					time += proc[i].remainingTime;
					proc[i].remainingTime = 0;
					proc[i].waitingTime = time - proc[i].bt;
				}
			}

		if (done == true) 
			break;
	}
	print(proc, n);
}

int main() {
	int n, quantum;
	process proc[maxN];
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
	cin >> n;
	cin >> quantum;
	for (int i = 0; i < n; i++) {
		cin >> proc[i].pid
			>> proc[i].art
			>> proc[i].bt;
		proc[i].turnArroundTime = 0;
		proc[i].waitingTime = 0;
		proc[i].respondTime = -1;
		proc[i].serviceTime = 0;
		proc[i].finishTime = -1;
		proc[i].remainingTime = proc[i].bt;
	}
	FCFS(proc, n);
	SJF(proc, n);
	SRTF(proc, n);
	QT(proc, n, quantum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}