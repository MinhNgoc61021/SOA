import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ExtentContiguousAllocation extends JFrame {
	JTextField txtExtent;
	JTextField txtBlockSize;
	JTextField txtLogicalAddress;
	JTextField txtExtentNumber;
	JTextField txtBlockNumber;
	JTextField txtOffset;
	JComboBox<String> cmbSize1;
	JComboBox<String> cmbSize2;
	JButton btnRun;

	public ExtentContiguousAllocation(String title) {
		super(title);
		this.addControls();
		this.addEvents();
	}

	private void addControls() {
		Container con = getContentPane();

		JPanel pnMain = new JPanel();
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		con.add(pnMain);

		String size[] = { "Bytes", "KB", "MB", "GB" };

		JPanel pnRow0 = new JPanel();
		pnRow0.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblExtent = new JLabel("Extent");
		txtExtent = new JTextField(16);
		pnRow0.add(lblExtent);
		pnRow0.add(txtExtent);
		pnMain.add(pnRow0);
		
		JPanel pnRow1 = new JPanel();
		pnRow1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBS = new JLabel("Block Size");
		lblBS.setHorizontalAlignment(JLabel.RIGHT);
		txtBlockSize = new JTextField(10);
		cmbSize1 = new JComboBox<>(size);
		pnRow1.add(lblBS);
		pnRow1.add(txtBlockSize);
		pnRow1.add(cmbSize1);
		pnMain.add(pnRow1);

		JPanel pnRow2 = new JPanel();
		pnRow2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblLA = new JLabel("Logical Address");
		lblLA.setHorizontalAlignment(JLabel.RIGHT);
		txtLogicalAddress = new JTextField(10);
		cmbSize2 = new JComboBox<>(size);
		pnRow2.add(lblLA);
		pnRow2.add(txtLogicalAddress);
		pnRow2.add(cmbSize2);
		lblBS.setPreferredSize(lblLA.getPreferredSize());
		pnMain.add(pnRow2);

		JPanel pnRow3 = new JPanel();
		pnRow3.setLayout(new FlowLayout());
		btnRun = new JButton("Run");
		pnRow3.add(btnRun);
		pnMain.add(pnRow3);

		JPanel pnRow4 = new JPanel();
		pnRow4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblExtentNumber = new JLabel("Extent Number");
		lblExtentNumber.setHorizontalAlignment(JLabel.RIGHT);
		lblExtentNumber.setPreferredSize(lblLA.getPreferredSize());
		txtExtentNumber = new JTextField(16);
		txtExtentNumber.setEditable(false);
		pnRow4.add(lblExtentNumber);
		pnRow4.add(txtExtentNumber);
		pnMain.add(pnRow4);
		
		JPanel pnRow5 = new JPanel();
		pnRow5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBN = new JLabel("Block Number");
		txtBlockNumber = new JTextField(16);
		pnRow5.add(lblBN);
		pnRow5.add(txtBlockNumber);
		lblBN.setPreferredSize(lblLA.getPreferredSize());
		lblBN.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow5);

		JPanel pnRow6 = new JPanel();
		pnRow6.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblOffset = new JLabel("Offset");
		txtOffset = new JTextField(16);
		pnRow6.add(lblOffset);
		pnRow6.add(txtOffset);
		lblOffset.setPreferredSize(lblLA.getPreferredSize());
		lblOffset.setHorizontalAlignment(JLabel.RIGHT);
		lblExtent.setPreferredSize(lblLA.getPreferredSize());
		lblExtent.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow6);

		txtBlockNumber.setEditable(false);
		txtOffset.setEditable(false);
	}

	private void addEvents() {
		btnRun.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!txtExtent.getText().equals("") && !txtBlockSize.getText().equals("") && !txtLogicalAddress.getText().equals(""))
				{
					int extent = Integer.parseInt(txtExtent.getText());
					double blockSize = Double.parseDouble(txtBlockSize.getText());
					double logicalAdd = Double.parseDouble(txtLogicalAddress.getText());
					blockSize = edit(blockSize, cmbSize1.getSelectedItem() + "");
					logicalAdd = edit(logicalAdd, cmbSize2.getSelectedItem() + "");
					double extentSize = extent * blockSize;
					txtExtentNumber.setText((int)(logicalAdd/extentSize) + "");
					txtBlockNumber.setText((int)((logicalAdd % extentSize)/blockSize) + "");
					txtOffset.setText((int)((logicalAdd % extentSize) % blockSize) + "");
				}
			}
		});
	}

	public double edit(double x, String type) {
		if (type.equals("Bytes")) {
			return x;
		} else if (type.equals("KB")) {
			return x * 1024;
		} else if (type.equals("MB")) {
			return x * 1024 * 1024;
		} else {
			return x * 1024 * 1024 * 1024;
		}

	}

	public void showWindow() {
		this.setSize(400, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}

	public static void main(String[] args) {
		ExtentContiguousAllocation ui = new ExtentContiguousAllocation("Extent Contiguous Allocation");
		ui.showWindow();
	}

}
