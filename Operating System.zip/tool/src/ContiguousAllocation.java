import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ContiguousAllocation extends JFrame {

	JTextField txtBlockSize;
	JTextField txtLogicalAddress;
	JTextField txtBlockNumber;
	JTextField txtOffset;
	JComboBox<String> cmbSize1;
	JComboBox<String> cmbSize2;
	JButton btnRun;

	public ContiguousAllocation(String title) {
		super(title);
		this.addControls();
		this.addEvents();
	}

	private void addControls() {
		Container con = getContentPane();

		JPanel pnMain = new JPanel();
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		con.add(pnMain);

		String size[] = { "Bytes", "KB", "MB", "GB" };

		JPanel pnRow1 = new JPanel();
		pnRow1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBS = new JLabel("Block Size");
		lblBS.setHorizontalAlignment(JLabel.RIGHT);
		txtBlockSize = new JTextField(10);
		cmbSize1 = new JComboBox<>(size);
		pnRow1.add(lblBS);
		pnRow1.add(txtBlockSize);
		pnRow1.add(cmbSize1);
		pnMain.add(pnRow1);

		JPanel pnRow2 = new JPanel();
		pnRow2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblLA = new JLabel("Logical Address");
		lblLA.setHorizontalAlignment(JLabel.RIGHT);
		txtLogicalAddress = new JTextField(10);
		cmbSize2 = new JComboBox<>(size);
		pnRow2.add(lblLA);
		pnRow2.add(txtLogicalAddress);
		pnRow2.add(cmbSize2);
		lblBS.setPreferredSize(lblLA.getPreferredSize());
		pnMain.add(pnRow2);

		JPanel pnRow3 = new JPanel();
		pnRow3.setLayout(new FlowLayout());
		btnRun = new JButton("Run");
		pnRow3.add(btnRun);
		pnMain.add(pnRow3);

		JPanel pnRow4 = new JPanel();
		pnRow4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBN = new JLabel("Block Number");
		txtBlockNumber = new JTextField(16);
		pnRow4.add(lblBN);
		pnRow4.add(txtBlockNumber);
		lblBN.setPreferredSize(lblLA.getPreferredSize());
		lblBN.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow4);

		JPanel pnRow5 = new JPanel();
		pnRow5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblOffset = new JLabel("Offset");
		txtOffset = new JTextField(16);
		pnRow5.add(lblOffset);
		pnRow5.add(txtOffset);
		lblOffset.setPreferredSize(lblLA.getPreferredSize());
		lblOffset.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow5);

		txtBlockNumber.setEditable(false);
		txtOffset.setEditable(false);
		
	}

	private void addEvents() {
		btnRun.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!txtBlockSize.getText().equals("") && !txtLogicalAddress.getText().equals(""))
				{
					double blockSize = Double.parseDouble(txtBlockSize.getText());
					double logicalAdd = Double.parseDouble(txtLogicalAddress.getText());
					blockSize = edit(blockSize, cmbSize1.getSelectedItem() + "");
					logicalAdd = edit(logicalAdd, cmbSize2.getSelectedItem() + "");
					txtBlockNumber.setText((int)(logicalAdd/blockSize) + "");
					txtOffset.setText((int)(logicalAdd % blockSize) + "");
				}
			}
		});
	}

	public double edit(double x, String type) {
		if (type.equals("Bytes")) {
			return x;
		} else if (type.equals("KB")) {
			return x * 1024;
		} else if (type.equals("MB")) {
			return x * 1024 * 1024;
		} else {
			return x * 1024 * 1024 * 1024;
		}

	}

	public void showWindow() {
		this.setSize(400, 200);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}

	public static void main(String[] args) {
		ContiguousAllocation ui = new ContiguousAllocation("Contiguous Allocation");
		ui.showWindow();
	}

}
