import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LinkedAllocation extends JFrame {
	JTextField txtPointerSize;
	JTextField txtBlockSize;
	JTextField txtLogicalAddress;
	JTextField txtDataPartSize;
	JTextField txtBlockNumber;
	JTextField txtOffset;
	JComboBox<String> cmbSize0;
	JComboBox<String> cmbSize1;
	JComboBox<String> cmbSize2;
	JButton btnRun;

	public LinkedAllocation(String title) {
		super(title);
		this.addControls();
		this.addEvents();
	}

	private void addControls() {
		Container con = getContentPane();

		JPanel pnMain = new JPanel();
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		con.add(pnMain);

		String size[] = { "Bytes", "KB", "MB", "GB" };

		JPanel pnRow0 = new JPanel();
		pnRow0.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblPointerSize = new JLabel("Pointer Size");
		txtPointerSize = new JTextField(10);
		cmbSize0 = new JComboBox<>(size);
		pnRow0.add(lblPointerSize);
		pnRow0.add(txtPointerSize);
		pnRow0.add(cmbSize0);
		pnMain.add(pnRow0);
		
		JPanel pnRow1 = new JPanel();
		pnRow1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBS = new JLabel("Block Size");
		lblBS.setHorizontalAlignment(JLabel.RIGHT);
		txtBlockSize = new JTextField(10);
		cmbSize1 = new JComboBox<>(size);
		pnRow1.add(lblBS);
		pnRow1.add(txtBlockSize);
		pnRow1.add(cmbSize1);
		pnMain.add(pnRow1);

		JPanel pnRow2 = new JPanel();
		pnRow2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblLA = new JLabel("Logical Address");
		lblLA.setHorizontalAlignment(JLabel.RIGHT);
		txtLogicalAddress = new JTextField(10);
		cmbSize2 = new JComboBox<>(size);
		pnRow2.add(lblLA);
		pnRow2.add(txtLogicalAddress);
		pnRow2.add(cmbSize2);
		lblBS.setPreferredSize(lblLA.getPreferredSize());
		pnMain.add(pnRow2);

		JPanel pnRow3 = new JPanel();
		pnRow3.setLayout(new FlowLayout());
		btnRun = new JButton("Run");
		pnRow3.add(btnRun);
		pnMain.add(pnRow3);

		JPanel pnRow4 = new JPanel();
		pnRow4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblDataPartSize = new JLabel("Data Part Size");
		lblDataPartSize.setHorizontalAlignment(JLabel.RIGHT);
		lblDataPartSize.setPreferredSize(lblLA.getPreferredSize());
		txtDataPartSize = new JTextField(16);
		txtDataPartSize.setEditable(false);
		pnRow4.add(lblDataPartSize);
		pnRow4.add(txtDataPartSize);
		pnMain.add(pnRow4);
		
		JPanel pnRow5 = new JPanel();
		pnRow5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBN = new JLabel("Block Number");
		txtBlockNumber = new JTextField(16);
		pnRow5.add(lblBN);
		pnRow5.add(txtBlockNumber);
		lblBN.setPreferredSize(lblLA.getPreferredSize());
		lblBN.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow5);

		JPanel pnRow6 = new JPanel();
		pnRow6.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblOffset = new JLabel("Offset");
		txtOffset = new JTextField(16);
		pnRow6.add(lblOffset);
		pnRow6.add(txtOffset);
		lblOffset.setPreferredSize(lblLA.getPreferredSize());
		lblOffset.setHorizontalAlignment(JLabel.RIGHT);
		lblPointerSize.setPreferredSize(lblLA.getPreferredSize());
		lblPointerSize.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow6);

		txtBlockNumber.setEditable(false);
		txtOffset.setEditable(false);
	}

	private void addEvents() {
		btnRun.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!txtPointerSize.getText().equals("") && !txtBlockSize.getText().equals("") && !txtLogicalAddress.getText().equals(""))
				{
					double pointerSize = Double.parseDouble(txtPointerSize.getText());
					double blockSize = Double.parseDouble(txtBlockSize.getText());
					double logicalAdd = Double.parseDouble(txtLogicalAddress.getText());
					pointerSize = edit(pointerSize, cmbSize0.getSelectedItem() + "");
					blockSize = edit(blockSize, cmbSize1.getSelectedItem() + "");
					logicalAdd = edit(logicalAdd, cmbSize2.getSelectedItem() + "");
					double dataPartSize = blockSize - pointerSize;
					txtDataPartSize.setText((int)dataPartSize + "");
					txtBlockNumber.setText((int)(logicalAdd/dataPartSize) + "");
					txtOffset.setText((int)((logicalAdd % dataPartSize) + pointerSize) + "");
				}
			}
		});
	}

	public double edit(double x, String type) {
		if (type.equals("Bytes")) {
			return x;
		} else if (type.equals("KB")) {
			return x * 1024;
		} else if (type.equals("MB")) {
			return x * 1024 * 1024;
		} else {
			return x * 1024 * 1024 * 1024;
		}

	}

	public void showWindow() {
		this.setSize(400, 300);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
	}

	public static void main(String[] args) {
		LinkedAllocation ui = new LinkedAllocation("Linked Allocation");
		ui.showWindow();
	}
}
