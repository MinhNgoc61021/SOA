package DiskScheduling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class SCAN {

	public static int sum(ArrayList<Integer> list) {
		int sum = 0;
		for (int x : list) {
			sum += x;
		}
		return sum;
	}

	public static int bigger(ArrayList<Integer> arr, int current) {
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i) >= current) {
				return i;
			}
		}
		return -1;
	}

	public static int smaller(ArrayList<Integer> arr, int current) {
		int index = -1;
		for (int i = 0; i < arr.size(); i++) {
			if (arr.get(i) <= current) {
				index = i;
			}
		}
		return index;
	}

	public static boolean checkArr(boolean check[]) {
		for (int i = 0; i < check.length; i++) {
			if (check[i] == true) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a, b;
		System.out.println("Nhap 2 dau mut ");
		a = scanner.nextInt();
		b = scanner.nextInt();
		System.out.println("Nhap so luong request");
		int n = scanner.nextInt();
		ArrayList<Integer> arr = new ArrayList<>();
		System.out.println("Nhap cac request");
		for (int i = 0; i < n; i++) {
			int x = scanner.nextInt();
			arr.add(x);
		}
		System.out.println("Nhap request hien tai");
		int current = scanner.nextInt();
		ArrayList<Integer> list = new ArrayList<>();
		int position = 1;
		System.out.println("Nhap huong(L/R)");
		String direction = scanner.next();

		Collections.sort(arr);
		if (direction.equals("L")) {
			while (arr.size() > 0) {
				int smaller_index = smaller(arr, current);
				if (smaller_index != -1 && current != a) {
					list.add(Math.abs(current - arr.get(smaller_index)));
					System.out.println("Doan " + position + ": " + current + "->" + arr.get(smaller_index)
							+ "; Length: " + Math.abs(arr.get(smaller_index) - current));
					position++;
					current = arr.get(smaller_index);
					arr.remove(smaller_index);
				} else if (smaller_index == -1 && current != a) {
					list.add(Math.abs(current - a));
					System.out.println(
							"Doan " + position + ": " + current + "->" + a + "; Length: " + Math.abs(a - current));
					position++;
					current = a;
				} else if (smaller_index == -1 && current == a) {
					while (arr.size() > 0) {
						list.add(Math.abs(current - arr.get(0)));
						System.out.println("Doan " + position + ": " + current + "->" + arr.get(0) + "; Length: "
								+ Math.abs(arr.get(0) - current));
						position++;
						current = arr.get(0);
						arr.remove(0);
					}
				}

			}

		} else if (direction.equals("R")) {
			while (arr.size() > 0) {
				int bigger_index = bigger(arr, current);
				if (bigger_index != -1 && current != b) {
					list.add(Math.abs(current - arr.get(bigger_index)));
					System.out.println("Doan " + position + ": " + current + "->" + arr.get(bigger_index) + "; Length: "
							+ Math.abs(arr.get(bigger_index) - current));
					position++;
					current = arr.get(bigger_index);
					arr.remove(bigger_index);
				} else if (bigger_index == -1 && current != b) {
					list.add(Math.abs(current - b));
					System.out.println(
							"Doan " + position + ": " + current + "->" + b + "; Length: " + Math.abs(b - current));
					position++;
					current = b;
				} else if (bigger_index == -1 && current == b) {
					while (arr.size() > 0) {
						list.add(Math.abs(current - arr.get(arr.size() - 1)));
						System.out.println("Doan " + position + ": " + current + "->" + arr.get(arr.size() - 1)
								+ "; Length: " + Math.abs(arr.get(arr.size() - 1) - current));
						position++;
						current = arr.get(arr.size() - 1);
						arr.remove(arr.size() - 1);
					}
				}
			}
		}
		System.out.println("Seek time = seek distance = " + sum(list));
	}

}
