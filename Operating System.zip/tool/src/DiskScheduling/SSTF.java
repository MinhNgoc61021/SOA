package DiskScheduling;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class SSTF {

	public static int sum(ArrayList<Integer> list) {
		int sum = 0;
		for (int x : list) {
			sum += x;
		}
		return sum;
	}

	public static int min(ArrayList<Integer> arr) {
		int min = arr.get(0);
		int key = 0;
		for (int i = 1; i < arr.size(); i++) {
			if (arr.get(i) < min) {
				min = arr.get(i);
				key = i;
			}
		}
		return key;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a, b;
		System.out.println("Nhap 2 dau mut ");
		a = scanner.nextInt();
		b = scanner.nextInt();
		System.out.println("Nhap so luong request");
		int n = scanner.nextInt();
		ArrayList<Integer> arr = new ArrayList<>();
		System.out.println("Nhap cac request");
		for (int i = 0; i < n; i++) {
			int x = scanner.nextInt();
			arr.add(x);
		}
		System.out.println("Nhap request hien tai");
		int current = scanner.nextInt();
		ArrayList<Integer> list = new ArrayList<>();
		int position = 1;

		for (int i = 0; i < n; i++) {
			ArrayList<Integer> distance = new ArrayList<>();
			for (int j = 0; j < arr.size(); j++) {
				distance.add(Math.abs(current - arr.get(j)));
			}
			int min_index = min(distance);
			list.add(Math.abs(arr.get(min_index) - current));
			System.out.println("Doan " + position + ": " + current + "->" + arr.get(min_index) + "; Length: "
					+ Math.abs(arr.get(min_index) - current));
			current = arr.get(min_index);
			position++;
			arr.remove(min_index);
		}
		System.out.println("Seek time = seek distance = " + sum(list));
	}

}
