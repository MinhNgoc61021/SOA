package DiskScheduling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class FCFS {

	public static int sum(ArrayList<Integer> list) {
		int sum = 0;
		for (int x : list) {
			sum += x;
		}
		return sum;
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a, b;
		System.out.println("Nhap 2 dau mut ");
		a = scanner.nextInt();
		b = scanner.nextInt();
		System.out.println("Nhap so luong request");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		System.out.println("Nhap cac request");
		for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
		}
		System.out.println("Nhap request hien tai");
		int current = scanner.nextInt();
		ArrayList<Integer> list = new ArrayList<>();

		System.out.println("Doan " + 1 + ": " + current + "->" + arr[0] + "; Length: " + Math.abs(arr[0] - current));
		list.add(Math.abs(arr[0] - current));
		for (int i = 1; i < n; i++) {
			System.out.println("Doan " + (i + 1) + ": " + arr[i - 1] + "->" + arr[i] + "; Length: "
					+ Math.abs(arr[i] - arr[i - 1]));
			list.add(Math.abs(arr[i] - arr[i - 1]));
		}
		System.out.println("Seek time = seek distance = " + sum(list));
	}

}
