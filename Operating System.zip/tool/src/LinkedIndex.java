import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LinkedIndex extends JFrame {

	JTextField txtPointerSize;
	JTextField txtBlockSize;
	JTextField txtLogicalAddress;
	JTextField txtPointer_Block;
	JTextField txtDataPointer;
	JTextField txtIndexBlock;
	JTextField txtBlockNumber;
	JTextField txtOffset;
	JComboBox<String> cmbSize0;
	JComboBox<String> cmbSize1;
	JComboBox<String> cmbSize2;
	JButton btnRun;
	
	public LinkedIndex(String title) {
		super(title);
		this.addControls();
		this.addEvents();
	}
	
	private void addControls() {
		Container con = getContentPane();

		JPanel pnMain = new JPanel();
		pnMain.setLayout(new BoxLayout(pnMain, BoxLayout.Y_AXIS));
		con.add(pnMain);

		String size[] = { "Bytes", "KB", "MB", "GB" };

		JPanel pnRow0 = new JPanel();
		pnRow0.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblPointerSize = new JLabel("Pointer Size");
		txtPointerSize = new JTextField(10);
		cmbSize0 = new JComboBox<>(size);
		pnRow0.add(lblPointerSize);
		pnRow0.add(txtPointerSize);
		pnRow0.add(cmbSize0);
		pnMain.add(pnRow0);
		
		JPanel pnRow1 = new JPanel();
		pnRow1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBS = new JLabel("Block Size");
		lblBS.setHorizontalAlignment(JLabel.RIGHT);
		txtBlockSize = new JTextField(10);
		cmbSize1 = new JComboBox<>(size);
		pnRow1.add(lblBS);
		pnRow1.add(txtBlockSize);
		pnRow1.add(cmbSize1);
		pnMain.add(pnRow1);

		JPanel pnRow2 = new JPanel();
		pnRow2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblLA = new JLabel("Logical Address");
		lblLA.setHorizontalAlignment(JLabel.RIGHT);
		txtLogicalAddress = new JTextField(10);
		cmbSize2 = new JComboBox<>(size);
		pnRow2.add(lblLA);
		pnRow2.add(txtLogicalAddress);
		pnRow2.add(cmbSize2);
		lblBS.setPreferredSize(lblLA.getPreferredSize());
		pnMain.add(pnRow2);

		JPanel pnRow3 = new JPanel();
		pnRow3.setLayout(new FlowLayout());
		btnRun = new JButton("Run");
		pnRow3.add(btnRun);
		pnMain.add(pnRow3);

		JPanel pnRow4 = new JPanel();
		pnRow4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblPointer_Block = new JLabel("Pointers/Blocks");
		lblPointer_Block.setHorizontalAlignment(JLabel.RIGHT);
		lblPointer_Block.setPreferredSize(lblLA.getPreferredSize());
		txtPointer_Block = new JTextField(16);
		txtPointer_Block.setEditable(false);
		pnRow4.add(lblPointer_Block);
		pnRow4.add(txtPointer_Block);
		pnMain.add(pnRow4);
		lblPointerSize.setPreferredSize(lblLA.getPreferredSize());
		lblPointerSize.setHorizontalAlignment(JLabel.RIGHT);

		JPanel pnRow5 = new JPanel();
		pnRow5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblDataPointer = new JLabel("Data Pointer");
		lblDataPointer.setHorizontalAlignment(JLabel.RIGHT);
		lblDataPointer.setPreferredSize(lblLA.getPreferredSize());
		txtDataPointer = new JTextField(16);
		txtDataPointer.setEditable(false);
		pnRow5.add(lblDataPointer);
		pnRow5.add(txtDataPointer);
		pnMain.add(pnRow5);
		
		JPanel pnRow6 = new JPanel();
		pnRow6.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblIndexBlock = new JLabel("Index Block");
		lblIndexBlock.setHorizontalAlignment(JLabel.RIGHT);
		lblIndexBlock.setPreferredSize(lblLA.getPreferredSize());
		txtIndexBlock = new JTextField(16);
		txtIndexBlock.setEditable(false);
		pnRow6.add(lblIndexBlock);
		pnRow6.add(txtIndexBlock);
		pnMain.add(pnRow6);
		
		JPanel pnRow7 = new JPanel();
		pnRow7.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblBN = new JLabel("Block Number");
		txtBlockNumber = new JTextField(16);
		txtBlockNumber.setEditable(false);
		pnRow7.add(lblBN);
		pnRow7.add(txtBlockNumber);
		lblBN.setPreferredSize(lblLA.getPreferredSize());
		lblBN.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow7);

		JPanel pnRow8 = new JPanel();
		pnRow8.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel lblOffset = new JLabel("Offset");
		txtOffset = new JTextField(16);
		txtOffset.setEditable(false);
		pnRow8.add(lblOffset);
		pnRow8.add(txtOffset);
		lblOffset.setPreferredSize(lblLA.getPreferredSize());
		lblOffset.setHorizontalAlignment(JLabel.RIGHT);
		lblPointerSize.setPreferredSize(lblLA.getPreferredSize());
		lblPointerSize.setHorizontalAlignment(JLabel.RIGHT);
		pnMain.add(pnRow8);
	}

	private void addEvents() {
		btnRun.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!txtPointerSize.getText().equals("") && !txtBlockSize.getText().equals("") && !txtLogicalAddress.getText().equals(""))
				{
					double pointerSize = Double.parseDouble(txtPointerSize.getText());
					double blockSize = Double.parseDouble(txtBlockSize.getText());
					double logicalAdd = Double.parseDouble(txtLogicalAddress.getText());
					pointerSize = edit(pointerSize, cmbSize0.getSelectedItem() + "");
					blockSize = edit(blockSize, cmbSize1.getSelectedItem() + "");
					logicalAdd = edit(logicalAdd, cmbSize2.getSelectedItem() + "");
					double pointers = blockSize / pointerSize;
					txtPointer_Block.setText((int)pointers + "");
					txtDataPointer.setText((int)pointers - 1 + "");
					txtIndexBlock.setText((int)(logicalAdd/((pointers - 1)*blockSize)) + "");
					txtBlockNumber.setText((int)((logicalAdd % ((pointers - 1)*blockSize)) / blockSize) + "");
					txtOffset.setText((int)((logicalAdd % ((pointers - 1)*blockSize)) % blockSize) + "");
				}
			}
		});
	}
	
	public double edit(double x, String type) {
		if (type.equals("Bytes")) {
			return x;
		} else if (type.equals("KB")) {
			return x * 1024;
		} else if (type.equals("MB")) {
			return x * 1024 * 1024;
		} else {
			return x * 1024 * 1024 * 1024;
		}

	}

	public void showWindow()
	{
		this.setSize(350,600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		LinkedIndex ui = new LinkedIndex("Linked Index");
		ui.showWindow();
	}

}
