package UnixFileSystem;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap block size");
		double blockSize = scanner.nextDouble();
		System.out.println("Nhap kieu du lieu(Bytes/KB/MB/GB");
		String typeBS = scanner.next();
		System.out.println("Nhap pointer size");
		double pointerSize = scanner.nextDouble();
		System.out.println("Nhap kieu du lieu(Bytes/KB/MB/GB");
		String typePS = scanner.next();
		System.out.println("Nhap dia chi logic");
		double logicAdd = scanner.nextDouble();
		System.out.println("Nhap kieu du lieu(Bytes/KB/MB/GB");
		String typeLA = scanner.next();
				
		blockSize = edit(blockSize, typeBS);
		pointerSize = edit(pointerSize, typePS);
		logicAdd = edit(logicAdd, typeLA);
		
		double pointers = blockSize / pointerSize;
		System.out.println("Pointers = " + (int)pointers);
		
		int direct = 12;
		int SIP = 12 + (int)pointers;
		int DIP = (int)Math.pow(pointers, 2) + SIP;
		int TIP = (int)Math.pow(pointers, 3) + DIP;
		
		System.out.println("--------");
		System.out.println("Direct = " + direct);
		System.out.println("SIP = " + SIP);
		System.out.println("DIP = " + DIP);
		System.out.println("TIP = " + TIP);
		System.out.println("--------");
		
		double blockNo = logicAdd / blockSize;
		System.out.println("Block Number = " + (int)blockNo);
		if (blockNo > DIP && blockNo <= TIP)
		{
			System.out.println("==> Triple indirect pointer");
			int position = (int)blockNo - DIP;
			System.out.println("Position in TIP = " + position);
			double block1 = position / (int)Math.pow(pointers, 2);
			System.out.println("Block1 = " + (int)block1);
			double block2 = (position % (int)Math.pow(pointers, 2))/pointers;
			System.out.println("Block2 = " + (int)block2);
			double block3 = (position % (int)Math.pow(pointers, 2)) % pointers;
			System.out.println("Block3 = " + (int)block3);
			double offset = logicAdd % blockSize;
			System.out.println("Offset = " + (int)offset);
		}
		else if (blockNo > SIP && blockNo <= DIP)
		{
			System.out.println("==> Double indirect pointer");
			double position = blockNo - SIP;
			System.out.println("Position in DIP = " + (int)position);
			double block1 = position / pointers;
			System.out.println("Block1 = " + (int)block1);
			double block2 = position % pointers;
			System.out.println("Block2 = " + (int)block2);
			double offset = logicAdd % blockSize;
			System.out.println("Offset = " + (int)offset);
		}
		else if (blockNo > direct && blockNo <= SIP)
		{
			System.out.println("==> Single indirect pointer");
			System.out.println("Position in SIP = " + (int)(blockNo - direct));
			System.out.println("Offset = " + (int)(logicAdd % blockSize));
		}
		else if (blockNo <= direct)
		{
			System.out.println("==> Direct pointer");
			System.out.println("Position = " + (int)(blockNo + 1));
			System.out.println("Offset = " + (int)(logicAdd % blockSize));
		}
	}
	
	public static double edit(double x, String type) {
		if (type.equals("Bytes")) {
			return x;
		} else if (type.equals("KB")) {
			return x * 1024;
		} else if (type.equals("MB")) {
			return x * 1024 * 1024;
		} else {
			return x * 1024 * 1024 * 1024;
		}
	}

}
