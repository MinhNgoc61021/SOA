import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Optimal {
	
	public static boolean check(int x, ArrayList<Integer> frame)
	{
		for (int i = 0; i < frame.size(); i++)
		{
			if (frame.get(i) == x)
			{
				return true;
			}
		}
		return false;
	}
	
	public static int index(int x, int i, int arr[])
	{
		for (int j = i + 1; j < arr.length; j++)
		{
			if (arr[j] == x)
			{
				return j;
			}
		}
		return -1;
	}
	
	public static int countFalse(int index[])
	{
		int count = 0;
		for (int i = 0; i < index.length; i++)
		{
			if (index[i] == -1)
			{
				count++;
			}
		}
		return count;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap so luong frame");
		int size = scanner.nextInt();
		ArrayList<Integer> frame = new ArrayList<>();
		System.out.println("Nhap chieu dai chuoi");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		System.out.println("Nhap cac phan tu");
		for (int i = 0; i < n; i++)
		{
			arr[i] = scanner.nextInt();
		}
		
		ArrayList<Integer> swap = new ArrayList<>();
		int countF = arr.length;
		int replaced = 0;
		for (int i = 0; i < n; i++)
		{
			if (frame.size() != size)
			{
				frame.add(arr[i]);
				System.out.println("---------");
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.println("---------");
			}
			else
			{
				System.out.println("---------");
				if (!check(arr[i],frame))
				{
					int index[] = new int[size];
					for (int j = 0; j < size; j++)
					{
						index[j] = index(frame.get(j), i, arr);
					}
					if (countFalse(index) == 0)
					{
						int max = index[0];
						int key = 0;
						for (int j = 1; j < index.length; j++)
						{
							if (index[j] > max)
							{
								max = index[j];
								key = j;
							}
						}
						System.out.println("Replace: " + frame.get(key));
						swap.add(frame.get(key));
						frame.remove(key);
						replaced++;
						frame.add(key,arr[i]);
					}
					else if (countFalse(index) == 1)
					{
						int key = 0;
						for (int j = 0; j < index.length; j++)
						{
							if (index[j] == -1)
							{
								key = j;
							}
						}
						System.out.println("Replace: " + frame.get(key));
						swap.add(frame.get(key));
						frame.remove(key);
						replaced++;
						frame.add(key,arr[i]);
					}
					else
					{
						System.out.println("Custom");
						replaced++;
					}
				}
				else
				{
					countF--;
				}
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.println("---------");
			}
		}
		System.out.println("Page fault   : " + countF);
		System.out.println("Replaced     : " + replaced);
		System.out.println("Order of swap: " + swap.toString());
	}
}
