package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Thrashing {

	public static boolean check(int x, ArrayList<Integer> WSS)
	{
		for (int i = 0; i < WSS.size(); i++)
		{
			if (WSS.get(i) == x)
			{
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap delta: ");
		int delta = scanner.nextInt();
		System.out.println("Nhap chieu dai chuoi:");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		System.out.println("Nhap chuoi:");
		for (int i = 0 ; i < n; i++)
		{
			arr[i] = scanner.nextInt();
		}
		System.out.println("Nhap vi tri muon phan tich: ");
		int position = scanner.nextInt();
		
		ArrayList<Integer> WSS = new ArrayList<>();
		for (int i = position - 1; i >= position - delta; i--)
		{
			if (check(arr[i], WSS))
			{
				WSS.add(arr[i]);
			}
		}
		System.out.println("----------");
		System.out.println("WSS[] = " + WSS.toString());
		System.out.println("Size = " + WSS.size());
	}

}
