package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class SecondChance {

	
	public static int check(int x, ArrayList<Integer> frame)
	{
		for (int i = 0; i < frame.size(); i++)
		{
			if (frame.get(i) == x)
			{
				return i;
			}
		}
		return -1;
	}
	
	public static void output(int index[])
	{
		System.out.print("[");
		for (int i = 0; i < index.length; i++)
		{
			if (i != index.length - 1)
			{
				System.out.print(index[i] + ",");
			}
		}
		System.out.println(index[index.length - 1] + "]");
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap so luong frame");
		int size = scanner.nextInt();
		ArrayList<Integer> frame = new ArrayList<>();
		System.out.println("Nhap chieu dai chuoi");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		System.out.println("Nhap cac phan tu");
		for (int i = 0; i < n; i++)
		{
			arr[i] = scanner.nextInt();
		}
		
		ArrayList<Integer> swap = new ArrayList<>();
		int index[] = new int[size];
		Arrays.fill(index, 0);
		int countF = arr.length;
		int replaced = 0;
		int pointer = 0;
		for (int i = 0; i < n; i++)
		{
			if (frame.size() != size)
			{
				frame.add(arr[i]);
				System.out.println("---------");
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.print("index: ");
				output(index);
				System.out.println("---------");
			}
			else
			{
				System.out.println("---------");
				if (check(arr[i], frame) != -1)
				{
					index[check(arr[i], frame)] = 1;
					countF--;
				}
				else
				{
					while (index[pointer] == 1)
					{
						index[pointer] = 0;
						if (pointer != size - 1)
						{
							pointer++;
						}
						else
						{
							pointer = 0;
						}
					}
					System.out.println("Replaced: " + frame.get(pointer));
					swap.add(frame.get(pointer));
					replaced++;
					frame.remove(pointer);
					frame.add(pointer, arr[i]);
				}
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.print("index: ");
				output(index);
				System.out.println("---------");
			}
		}
		System.out.println("Page fault : " + countF);
		System.out.println("Replaced   : " + replaced);
		System.out.println("Order of swap: " + swap.toString());
	}

}
