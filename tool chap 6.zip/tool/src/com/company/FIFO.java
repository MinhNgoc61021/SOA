package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class FIFO {

	public static boolean check(int x, ArrayList<Integer> frame)
	{
		for (int i = 0; i < frame.size(); i++)
		{
			if (frame.get(i) == x)
			{
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nhap so luong frame");
		int size = scanner.nextInt();
		ArrayList<Integer> frame = new ArrayList<>();
		System.out.println("Nhap chieu dai chuoi");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		System.out.println("Nhap cac phan tu");
		for (int i = 0; i < n; i++)
		{
			arr[i] = scanner.nextInt();
		}
		
		ArrayList<Integer> swap = new ArrayList<>();
		int countF = arr.length;
		int replaced = 0;
		int fault = 0;
		for (int i = 0; i < n; i++)
		{
			if (frame.size() != size)
			{
				frame.add(arr[i]);
				System.out.println("---------");
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.println("---------");
			}
			else
			{
				System.out.println("---------");
				if (!check(arr[i],frame))
				{
					System.out.println("Replace: " + frame.get(fault));
					swap.add(frame.get(fault));
					frame.remove(fault);
					replaced++;
					frame.add(fault, arr[i]);
					if (fault != size - 1)
					{
						fault++;
					}
					else
					{
						fault = 0;
					}
				}
				else
				{
					countF--;
				}
				System.out.println(arr[i] + ": " + frame.toString());
				System.out.println("---------");
			}
		}
		System.out.println("Page fault : " + countF);
		System.out.println("Replaced   : " + replaced);
		System.out.println("Order of swap: " + swap.toString());
	}

}
